#include <Arduino.h>
#include "GFX_Root/GFX.h"

#include "Displays/DEPG0150BNS810/DEPG0150BNS810.h"                     // Heltec 1.54" BW V2    -   Red Tab
#include "Displays/QYEG0213RWS800/QYEG0213RWS800.h"                     // Heltec 2.13" RED V2   -   Red Tab
#include "Displays/DEPG0290BNS75A/DEPG0290BNS75A.h"                     // Heltec 2.9" BW V2     -   Red Tab