This folder will contain a .h and .cpp file for each display.<br />
Each of these pairs will define a class, and will be imported into the main .h/.cpp files in src. 

Let the compiler trim away the ones we don't need.

See [identifying your display](/README.md#identifying-your-display)