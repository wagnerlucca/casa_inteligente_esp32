This folder contains GFX_Root 2.0.0 from https://github.com/ZinggJM/GFX_Root
Please find attached license files relevant to content in this folder
